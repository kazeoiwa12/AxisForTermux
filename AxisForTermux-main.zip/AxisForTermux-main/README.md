# Axis For Termux
Axis For Termux, dor sytem injection quota free with scrapper AXISnet.

# Screenshot
[![Muhammad Quillen](https://i.ibb.co/zRNbsQd/termux-apiaxis.jpg)](https://www.facebook.com/LyCoXyZ/) 

# Required Aplication
- Pastikan Termuxnya dari F-Droid Jangan dari Playstore, supaya enggak banyak yang error.

- Link Termux F-Droid [Termux](https://f-droid.org/repo/com.termux_118.apk) 
### Install
- Install **``paket yang dibutuhkan``** terlebih dahulu dengan membuka termux:

    ```
    pkg update && pkg install upgrade -y
    ```
    
    ```
    pkg install git -y
    ```
    
    ```
    git clone https://github.com/lycoxz/AxisForTermux.git
    ```

    ```
    cd AxisForTermux && chmod +x install && ./install
    ```
    
    ```
    ./install
    ```
    
### How Tow Run Inject Dor Axis
- Cara menjalankan **``dor``**

    ```
    cd
    ```
    
    ```
    ./dor
    ```

# Contact Me
- Bila masih bingung bisa di tanyakan 
- Facebook : [Muhammad Quillen](https://www.facebook.com/LyCoXyZ/) 
- Whatsapp : [Asep Hadad](https://wa.me/6283195323183) 

# Developer - Pengembang
- Base script and more enhancement codes by [Muhammad Quillen](https://www.facebook.com/LyCoXyZ/)
- installer and install dor codes by [Dedd](https://www.facebook.com/fookin.dr/) 
